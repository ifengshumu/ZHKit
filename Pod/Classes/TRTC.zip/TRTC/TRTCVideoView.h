//
//  TRTCVideoView.h
//  TXLiteAVDemo
//
//  Created by rushanting on 2019/3/5.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, VideoViewType) {
    VideoViewType_Local,
    VideoViewType_Remote,
};

@class TRTCVideoView;

@protocol TRTCVideoViewDelegate <NSObject>

@optional
- (void)onMuteVideoBtnClick:(TRTCVideoView*)view stateChanged:(BOOL)stateChanged;
- (void)onMuteAudioBtnClick:(TRTCVideoView*)view stateChanged:(BOOL)stateChanged;
- (void)onScaleModeBtnClick:(TRTCVideoView*)view stateChanged:(BOOL)stateChanged;
- (void)onViewTap:(TRTCVideoView*)view touchCount:(NSInteger)touchCount;
@end

@interface TRTCVideoView : UIImageView

@property (nonatomic, weak) id<TRTCVideoViewDelegate> delegate;
@property (nonatomic, readonly) NSString* userId;
@property (nonatomic, readonly) VideoViewType type;
@property (nonatomic, assign) BOOL enableMove;

@property (nonatomic, retain) UIButton* btnMuteVideo;
@property (nonatomic, retain) UIButton* btnMuteAudio;
@property (nonatomic, retain) UIButton* btnScaleMode;
@property (nonatomic, assign) int streamType;


+ (instancetype)newVideoViewWithType:(VideoViewType)type userId:( NSString * _Nullable )userId;

/// 设置呼叫状态视图
/// @param name 被呼叫或主叫者姓名
/// @param path 被呼叫或主叫者头像url
/// @param isCaller 是否是主叫
/// @param handler 按钮事件，0-取消，1-接听（被叫才有）
- (void)setCallStateViewWithName:(NSString *)name photoPath:(NSString *)path isCaller:(BOOL)isCaller handler:(void(^)(NSInteger index))handler;

/// 移除呼叫状态视图
- (void)removeCallStateView;

- (void)hideButtons:(BOOL)hide;
/// 设置网络状态
- (void)setNetworkIndicatorImage:(UIImage*)image;
- (void)showNetworkIndicatorImage:(BOOL)show;

/// 设置音量
- (void)setAudioVolumeRadio:(float)volumeRadio;
- (void)showAudioVolume:(BOOL)show;

- (void)showVideoCloseTip:(BOOL)show;

@end

NS_ASSUME_NONNULL_END
