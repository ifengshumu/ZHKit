//
//  TRTCSettingsLargeInputCell.h
//  TXLiteAVDemo
//
//  Created by LiuXiaoya on 2019/12/5.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "TRTCSettingsInputCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRTCSettingsLargeInputCell : TRTCSettingsInputCell

@end


@interface TRTCSettingsLargeInputItem : TRTCSettingsInputItem

@end

NS_ASSUME_NONNULL_END
