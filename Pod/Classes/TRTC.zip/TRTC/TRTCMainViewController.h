/*
 * Module:   TRTCMainViewController
 * 
 * Function: 使用TRTC SDK完成 1v1 和 1vn 的视频通话功能
 *
 *    1. 支持九宫格平铺和前后叠加两种不同的视频画面布局方式，该部分由 TRTCVideoViewLayout 来计算每个视频画面的位置排布和大小尺寸
 *
 *    2. 支持对视频通话的分辨率、帧率和流畅模式进行调整，该部分由 TRTCSettingViewController 来实现，暂不实现
 *
 *    3. 传入TRTCReadyParams，trtcViewControllerWithParams:启动
 */

#import "SPBaseController.h"
#import "TRTCCloudManager.h"
#import "TRTCCloud.h"
#import "TRTCRemoteUserManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TRTCReadyParams : TRTCParams
/// 被呼叫或主叫者姓名
@property (nonatomic, copy) NSString *userName;
/// 被呼叫或主叫者头像url
@property (nonatomic, copy) NSString *userPhoto;
/// 是否是主叫
@property (nonatomic, assign) BOOL isCaller;
/// 回调
@property (nonatomic, copy) void(^callback)(id roomId, NSInteger callState, NSInteger callDuration, NSInteger trigger);
@end

@interface TRTCMainViewController : SPBaseController

/// 初始化视频通话页面
/// @param params 初始化参数
+ (instancetype)trtcViewControllerWithParams:(TRTCReadyParams *)params;

- (void)setLocalView:(UIView*)localView remoteViewDic:(NSMutableDictionary*)remoteViewDic;

@end

NS_ASSUME_NONNULL_END
