/*
 * Module:   TRTCMainViewController
 * 
 * Function: 使用TRTC SDK完成 1v1 和 1vn 的视频通话功能
 *
 */

#import <AVFoundation/AVFoundation.h>
#import "TRTCMainViewController.h"
#import "UIView+Additions.h"
#import "ColorMacro.h"
#import "TCBeautyPanel.h"
#import "TRTCCloudDelegate.h"
#import "TRTCVideoViewLayout.h"
#import "TRTCVideoView.h"
#import "TXLivePlayer.h"
#import "TRTCCloudDef.h"
#import "TRTCFloatWindow.h"
#import "TRTCBgmContainerViewController.h"
#import "TRTCCdnPlayerSettingsViewController.h"
#import "TRTCRemoteUserListViewController.h"
#import "TRTCBgmManager.h"
#import "TRTCAudioEffectManager.h"
#import "TRTCAudioRecordManager.h"
#import "TRTCCdnPlayerManager.h"

#import "HomeNoticeAPI.h"

@implementation TRTCReadyParams

@end

@interface TRTCMainViewController()<TRTCCloudDelegate, TRTCVideoViewDelegate, TRTCCloudManagerDelegate> {
    
    NSString                 *_mainViewUserId;     //视频画面支持点击切换，需要用一个变量记录当前哪一路画面是全屏状态的
    
    TRTCVideoViewLayout      *_layoutEngine;
    NSMutableDictionary*      _remoteViewDic;      //一个或者多个远程画面的view
}

@property (strong, nonatomic)  UIView *holderView;
@property (strong, nonatomic) TRTCVideoView* localView; //本地画面的view
@property (strong, nonatomic) UILabel *tipsLabel;

/// TRTC SDK 视频通话房间进入所必须的参数
@property (strong, nonatomic) TRTCReadyParams *param;
@property (strong, nonatomic) TRTCCloudManager *settingsManager;
@property (strong, nonatomic) TRTCRemoteUserManager *remoteUserManager;
@property (assign, nonatomic) TRTCAppScene appScene;

@property (strong, nonatomic) TRTCCloud *trtc;
@property (strong, nonatomic) TCBeautyPanel *beautyPanel;
@property (strong, nonatomic) TRTCBgmManager *bgmManager;
@property (strong, nonatomic) TRTCAudioEffectManager *effectManager;
@property (strong, nonatomic) TRTCAudioRecordManager *recordManager;

@property (strong, nonatomic) NSTimer *callTimer;
@property (assign, nonatomic) NSInteger callTime;

@property (strong, nonatomic) NSTimer *timer;
@property (assign, nonatomic) NSInteger videoTime;
@property (assign, nonatomic) UIBackgroundTaskIdentifier timerTaskId;

@end

@implementation TRTCMainViewController

- (void)dealloc {
    [[TRTCFloatWindow sharedInstance] close];
    [TRTCCloud destroySharedIntance];
}

+ (instancetype)trtcViewControllerWithParams:(TRTCReadyParams *)params {
    TRTCMainViewController *vc = [[TRTCMainViewController alloc] initWithBarStyle:SPNavBarStyleHide];
    vc.param = params;
    vc.holderView = [[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    [vc.view addSubview:vc.holderView];
    return vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.watermark removeFromSuperview];
    _trtc = [TRTCCloud sharedInstance];
    [_trtc setDelegate:self];
    //音效，进入就开始播放
    self.effectManager = [[TRTCAudioEffectManager alloc] initWithTrtc:self.trtc];
    [self.effectManager setLoopCount:10000];
    [self.effectManager playEffect:0];
    //通知
    [self addObserver];
    //启动
    [self onReadyData];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES]; //保持屏幕常亮
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    [self invalidateCallTimer];
    [self invalidateTimer];
}

- (void)setLocalView:(UIView *)localView remoteViewDic:(NSMutableDictionary *)remoteViewDic {
    _trtc.delegate = self;
    _localView = (TRTCVideoView*)localView;
    _localView.delegate = self;
    self.settingsManager.videoView = self.localView;
    _remoteViewDic = remoteViewDic;
    if (_param.role != TRTCRoleAudience)
        _mainViewUserId = @"";
    
    for (id userID in _remoteViewDic) {
        TRTCVideoView *playerView = [_remoteViewDic objectForKey:userID];
        playerView.delegate = self;
    }
    [self relayout];
}

#pragma mark - 通知
- (void)addObserver {
    //退出通知
    [[NSNotificationCenter defaultCenter] addObserverForName:@"TRTC_ERROR_NEED_EXIT" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        NSInteger state = [self getStateWithResult:note.object];
        [self callbackWithRoomId:@0 state:state duration:0 trigger:0];
        if (self.param.isCaller) {
            [self exitRoom];
        } else {
            [self dismissVideoRoom];
        }
    }];
    //token失效需要登录
    [[NSNotificationCenter defaultCenter] addObserverForName:Refresh_Token_Error_Need_Login object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self dismissVideoRoom];
    }];
}
- (NSInteger)getStateWithResult:(NSNumber *)result {
    NSInteger state = 0;
    switch (result.integerValue) {
        case -1:
            state = 5;
            break;
        case -2:
            state = 2;
            break;
        case -3:
            state = 6;
            break;
        case -4:
            state = 7;
            break;
        default:
            state = 5;
            break;
    }
    return state;
}

#pragma mark - 签名、房间号等数据
- (void)onReadyData {
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_enter(group);
    [[HomeNoticeAPI makeInstance] getTRTCUserSigWithUserId:self.param.userId callback:^(BOOL finished, id reponseObject, NSInteger code) {
        if (finished && code == 200) {
            id data = reponseObject[@"data"];
            if ([data isKindOfClass:NSDictionary.class]) {
                self.param.sdkAppId = [data[@"sdkAppId"] unsignedIntValue];
                self.param.userSig = data[@"urlSign"];
            }
        }
        dispatch_group_leave(group);
    }];
    if (self.param.isCaller && !self.param.roomId) {
        dispatch_group_enter(group);
        [[HomeNoticeAPI makeInstance] getTRTCRoomIdWithCallback:^(BOOL finished, id reponseObject, NSInteger code) {
            if (finished && code == 200) {
                id data = reponseObject[@"data"];
                self.param.roomId = [data unsignedIntValue];
                //把roomID传给IM
                [self callbackWithRoomId:data state:0 duration:0 trigger:0];
            }
            dispatch_group_leave(group);
        }];
    }
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        //签名等数据请求失败
        if (!self.param.sdkAppId || !self.param.userSig || !self.param.roomId) {
            //通话失败回调
            [self callbackWithRoomId:@-100 state:5 duration:0 trigger:0];
            if (!self.param.isCaller) {
                [self callbackWithRoomId:@0 state:5 duration:0 trigger:0];
            }
            [self dismissVideoRoom];
            return;
        }
        //配置TRTC
        [self TRTCSetting];
        // 初始化 UI 控件
        [self initUI];
        self.settingsManager.videoView = self.localView;
        // 开始登录、进房
        if (self.param.isCaller) {
            [self enterRoom];
        } else {
            self.localView.image = [UIImage imageNamed:@"called_state"];
        }
    });
}

- (void)TRTCSetting {
    // TRTC相关参数设置
    TRTCParams *param = [[TRTCParams alloc] init];
    param.sdkAppId = self.param.sdkAppId;
    param.userId = self.param.userId;
    param.roomId = self.param.roomId;
    param.userSig = self.param.userSig;
    //远端用户设置
    TRTCRemoteUserManager *remoteManager = [[TRTCRemoteUserManager alloc] initWithTrtc:[TRTCCloud sharedInstance]];
    [remoteManager enableAutoReceiveAudio:YES autoReceiveVideo:YES];
    //TRTC SDK
    TRTCCloudManager *manager = [[TRTCCloudManager alloc] initWithTrtc:[TRTCCloud sharedInstance] params:param scene:TRTCAppSceneVideoCall appId:0 bizId:0];
    self.settingsManager = manager;
    self.remoteUserManager = remoteManager;
    self.appScene = TRTCAppSceneVideoCall;
    self.settingsManager.remoteUserManager = self.remoteUserManager;
    //美颜
    self.beautyPanel = [[TCBeautyPanel alloc] initWithFrame:CGRectZero theme:nil actionPerformer:[TCBeautyPanelActionProxy proxyWithSDKObject:_trtc]];
    //not use
    self.bgmManager = [[TRTCBgmManager alloc] initWithTrtc:self.trtc];
    self.recordManager = [[TRTCAudioRecordManager alloc] initWithTrtc:self.trtc];

    _remoteViewDic = [[NSMutableDictionary alloc] init];
    _mainViewUserId = @"";
}

- (void)initUI {
    // 本地预览view
    _localView = [TRTCVideoView newVideoViewWithType:VideoViewType_Local userId:self.param.userId];
    _localView.delegate = self;
    [_localView setBackgroundColor:UIColorFromRGB(0x262626)];
    @weakify(self);
    [_localView setCallStateViewWithName:self.param.userName photoPath:self.param.userPhoto isCaller:self.param.isCaller handler:^(NSInteger index) {
        @strongify(self);
        if (index == 0) {
            //取消
            [self invalidateCallTimer];
            if (self.param.isCaller) {
                [self callbackWithRoomId:@0 state:2 duration:0 trigger:0];
                [self exitRoom];
            } else {
                [self callbackWithRoomId:@0 state:6 duration:0 trigger:0];
                [self dismissVideoRoom];
            }
        } else {
            //接听
            self.localView.image = nil;
            [self enterRoom];
            //添加视频元素（在此处调用是为了防止远程摄像头不可用导致无法挂断）
            [self addVideoStateViewWithName];
            //停止播放音效
            [self.effectManager stopEffect:0];
        }
    }];
    //开始计时，60s未接通退出
    self.callTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(callTimeCount) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.callTimer forMode:NSRunLoopCommonModes];
    
    _layoutEngine = [[TRTCVideoViewLayout alloc] init];
    _layoutEngine.view = self.holderView;
    [self relayout];
}
#pragma mark - 视频元素
- (void)addVideoStateViewWithName {
    UILabel *nameLabel = [[UILabel alloc] init];
    nameLabel.tag = 11111;
    nameLabel.text = self.param.userName;
    nameLabel.textColor = UIColor.whiteColor;
    nameLabel.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:nameLabel];
    [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(TOP_BAR_HEIGHT + 20));
        make.left.equalTo(@20);
        make.right.equalTo(@-20);
    }];
    UILabel *timeLabel = [[UILabel alloc] init];
    timeLabel.tag = 11112;
    timeLabel.textColor = UIColor.whiteColor;
    timeLabel.font = [UIFont systemFontOfSize:16];
    [self.view addSubview:timeLabel];
    [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameLabel.mas_bottom).offset(2);
        make.left.equalTo(nameLabel);
    }];
    UIButton *cancelButton = [self callButton:@"取消" imageName:@"TRTC_cancel" touchedImage:@"TRTC_cancel_touch"];
    cancelButton.tag = 11113;
    [self.view addSubview:cancelButton];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(@(-30-TAB_BAR_SAFE_SPACE));
        make.centerX.equalTo(self.view);
    }];
    [cancelButton addActionHandler:^(UIButton * _Nonnull sender) {
        [self callbackWithRoomId:@0 state:4 duration:self.videoTime trigger:1];
        [self exitRoom];
    }];
}
- (UIButton *)callButton:(NSString *)title imageName:(NSString *)imageName touchedImage:(NSString *)touchedImageName {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:touchedImageName] forState:UIControlStateFocused];
    [button setImageTextAlignmentStyle:UIButtonImageAlignmentStyleTop space:12];
    return button;
}

- (void)bringVideoStateViewToFront {
    UIView *v = [self.view viewWithTag:11111];
    if (v) {
        [self.view bringSubviewToFront:v];
        for (NSInteger i = 1; i < 3; i++) {
            UIView *view = [self.view viewWithTag:11111 + i];
            [self.view bringSubviewToFront:view];
        }
    }
}

#pragma mark - 浮动视频窗口
- (void)back2FloatingWindow {
    [_trtc showDebugView:0];
    [TRTCFloatWindow sharedInstance].localView = _localView;
    [TRTCFloatWindow sharedInstance].remoteViewDic = _remoteViewDic;
    for (NSString* uid in _remoteViewDic) {
        TRTCVideoView* view = _remoteViewDic[uid];
        [view removeFromSuperview];
    }
    [TRTCFloatWindow sharedInstance].backController = self;
    // dismiss
    [self dismissViewControllerAnimated:YES completion:nil];
    [[TRTCFloatWindow sharedInstance] show];
}

#pragma mark - 提醒文案
- (void)showTips:(NSString *)tips {
    if (!self.tipsLabel) {
        UILabel *tipsLabel = [[UILabel alloc] init];
        tipsLabel.textColor = [UIColor colorWithHexString:@"#CACACD"];
        tipsLabel.font = [UIFont systemFontOfSize:16];
        self.tipsLabel = tipsLabel;
        [self.view addSubview:tipsLabel];
        [tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(@(-125-TAB_BAR_SAFE_SPACE));
            make.centerX.equalTo(self.view);
        }];
    }
    self.tipsLabel.hidden = NO;
    self.tipsLabel.text = tips;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.tipsLabel.hidden = YES;
    });
}

#pragma mark - 视频窗口排布
/**
 * 视频窗口排布函数，此处代码用于调整界面上数个视频画面的大小和位置
 */
- (void)relayout {
    NSMutableArray *views = @[].mutableCopy;
    if ([_mainViewUserId isEqual:@""] || [_mainViewUserId isEqual:self.param.userId]) {
        [views addObject:_localView];
        _localView.enableMove = NO;
    } else if([_remoteViewDic objectForKey:_mainViewUserId] != nil) {
        [views addObject:_remoteViewDic[_mainViewUserId]];
    }
    for (id userID in _remoteViewDic) {
        TRTCVideoView *playerView = [_remoteViewDic objectForKey:userID];
        if ([_mainViewUserId isEqual:userID]) {
            [views addObject:_localView];
            playerView.enableMove = NO;
            _localView.enableMove = YES;
        } else {
            playerView.enableMove = YES;
            [views addObject:playerView];
        }
    }
    
    [_layoutEngine relayout:views];
    
    //把通话状态元素移到最前面
    [self bringVideoStateViewToFront];
    
    //观众角色隐藏预览view
     _localView.hidden = NO;
     if (_appScene == TRTCAppSceneLIVE && _param.role == TRTCRoleAudience)
         _localView.hidden = YES;
}

#pragma mark - 进房
- (void)enterRoom {
    [self.settingsManager enterRoom];
    [self.beautyPanel resetAndApplyValues];
}

#pragma mark - 退房
- (void)exitRoom {
    [self.settingsManager exitRoom];
}

- (void)dismissVideoRoom {
    [self dismissViewControllerAnimated:YES completion:^{
        [self.effectManager stopEffect:0];
        [AppService defaultService].trtcParam = nil;
    }];
}

#pragma mark - 回调
- (void)callbackWithRoomId:(id)roomId state:(NSInteger)state duration:(NSInteger)duration trigger:(NSInteger)triggle {
    if (self.param.callback) {
        self.param.callback(roomId, state, duration, triggle);
    }
}

#pragma mark - 计时
//呼叫计时
- (void)callTimeCount {
    self.callTime++;
    if (self.callTime >= 60) {
        [self invalidateCallTimer];
        //通话状态回调
        [self callbackWithRoomId:@0 state:5 duration:0 trigger:0];
        if (self.param.isCaller) {
            [self exitRoom];
        } else {
            [self dismissVideoRoom];
        }
    }
}
- (void)invalidateCallTimer {
    if (self.callTimer) {
        [self.callTimer invalidate];
        self.callTimer = nil;
    }
}

//通话计时
- (void)videoTimeCount {
    self.videoTime++;
    NSInteger seconds = self.videoTime % 60;
    NSInteger minutes = (self.videoTime / 60) % 60;
    NSInteger hours = self.videoTime / 3600;
    NSString *final = [NSString stringWithFormat:@"%02ld:%02ld:%02ld",hours, minutes, seconds];
    UILabel *timeLabel = [self.view viewWithTag:11112];
    timeLabel.text = final;
}
- (void)invalidateTimer {
    if (self.timer) {
        [[UIApplication sharedApplication] endBackgroundTask:self.timerTaskId];
        [self.timer invalidate];
        self.timer = nil;
    }
}

#pragma mark - TRTCVideoViewDelegate
- (void)onMuteVideoBtnClick:(TRTCVideoView *)view stateChanged:(BOOL)stateChanged {
    if (view.streamType == TRTCVideoStreamTypeSub) {
        if (stateChanged) {
            [_trtc stopRemoteSubStreamView:view.userId];
        } else {
            [_trtc startRemoteSubStreamView:view.userId view:view];
        }
    } else {
        [self.remoteUserManager setUser:view.userId isVideoMuted:stateChanged];
    }
}

- (void)onMuteAudioBtnClick:(TRTCVideoView *)view stateChanged:(BOOL)stateChanged {
    [self.remoteUserManager setUser:view.userId isAudioMuted:stateChanged];
}

- (void)onScaleModeBtnClick:(TRTCVideoView *)view stateChanged:(BOOL)stateChanged {
    [self.remoteUserManager setUser:view.userId fillMode:stateChanged ? TRTCVideoFillMode_Fill : TRTCVideoFillMode_Fit];
}
//点击切换画面
- (void)onViewTap:(TRTCVideoView *)view touchCount:(NSInteger)touchCount {
    if (_layoutEngine.type == TC_Gird) {
        return;
    }
    if (view == _localView) {
        _mainViewUserId = self.param.userId;
    } else {
        for (id userID in _remoteViewDic) {
            UIView *pw = [_remoteViewDic objectForKey:userID];
            if (view == pw ) {
                _mainViewUserId = userID;
            }
        }
    }
    [self relayout];
}

#pragma mark - TRTCCloudDelegate
/**
 * WARNING 大多是一些可以忽略的事件通知，SDK内部会启动一定的补救机制
 */
- (void)onWarning:(TXLiteAVWarning)warningCode warningMsg:(NSString *)warningMsg {
    
}

/**
 * 大多是不可恢复的错误，需要通过 UI 提示用户
 */
- (void)onError:(TXLiteAVError)errCode errMsg:(NSString *)errMsg extInfo:(nullable NSDictionary *)extInfo {
    // 有些手机在后台时无法启动音频，这种情况下，TRTC会在恢复到前台后尝试重启音频，不应调用exitRoom。
    //存在说明在视频中
    UIView *v = [self.view viewWithTag:11111];
    if (v) {
        [self callbackWithRoomId:@0 state:4 duration:self.videoTime trigger:0];
        [self exitRoom];
    } else {
        NSInteger state = self.param.isCaller ? 2 : 6;
        [self callbackWithRoomId:@0 state:state duration:0 trigger:0];
        [self dismissVideoRoom];
    }
}

- (void)onEnterRoom:(NSInteger)result {
    if (result >= 0) {
        //如果是被叫，进房成功，停止呼叫计时，停止播放音效
        if (!self.param.isCaller) {
            [self invalidateCallTimer];
            [self.effectManager stopEffect:0];
            [self callbackWithRoomId:@0 state:3 duration:0 trigger:0];
        }
    } else {
        //进房失败
        [self exitRoom];
    }
}

- (void)onExitRoom:(NSInteger)reason {
    [self dismissVideoRoom];
}

/**
 * 有新的用户加入了当前视频房间
 */
- (void)onRemoteUserEnterRoom:(NSString *)userId {
    [self.remoteUserManager addUser:userId roomId:[NSString stringWithFormat:@"%@", @(self.param.roomId)]];
    if (self.param.isCaller) {
        //移除呼叫元素
        [_localView removeCallStateView];
        //添加视频元素，如果是被叫在点击【接听】时添加
        [self addVideoStateViewWithName];
        //停止播放音效
        [self.effectManager stopEffect:0];
    }
}

/**
 * 有用户离开了当前视频房间
 */
- (void)onRemoteUserLeaveRoom:(NSString *)userId reason:(NSInteger)reason {
    [self callbackWithRoomId:@0 state:4 duration:self.videoTime trigger:0];
    //退出房间
    [self exitRoom];
    
    
//    [self.remoteUserManager removeUser:userId];
//    // 更新UI
//    UIView *playerView = [_remoteViewDic objectForKey:userId];
//    [playerView removeFromSuperview];
//    [_remoteViewDic removeObjectForKey:userId];
//
//    NSString* subViewId = [NSString stringWithFormat:@"%@-sub", userId];
//    UIView *subStreamPlayerView = [_remoteViewDic objectForKey:subViewId];
//    [subStreamPlayerView removeFromSuperview];
//    [_remoteViewDic removeObjectForKey:subViewId];
//    // 如果该成员是大画面，则当其离开后，大画面设置为本地推流画面
//    if ([userId isEqual:_mainViewUserId] || [subViewId isEqualToString:_mainViewUserId]) {
//        _mainViewUserId = self.param.userId;
//    }
//    //重新布局
//    [self relayout];
//    [self.settingsManager updateCloudMixtureParams];
}

- (void)onUserAudioAvailable:(NSString *)userId available:(BOOL)available {
    [self.remoteUserManager updateUser:userId isAudioEnabled:available];

    TRTCVideoView *playerView = [_remoteViewDic objectForKey:userId];
    if (!available) {
        [playerView setAudioVolumeRadio:0.f];
    }
}

- (void)onUserVideoAvailable:(NSString *)userId available:(BOOL)available {
    [self.remoteUserManager updateUser:userId isVideoEnabled:available];
    if (userId != nil) {
        TRTCVideoView* remoteView = [_remoteViewDic objectForKey:userId];
        if (available) {
            if(remoteView == nil) {
                // 创建一个新的 View 用来显示新的一路画面
                remoteView = [TRTCVideoView newVideoViewWithType:VideoViewType_Remote userId:userId];
                if (!self.settingsManager.audioConfig.isVolumeEvaluationEnabled) {
                    [remoteView showAudioVolume:NO];
                }
                remoteView.delegate = self;
                [remoteView setBackgroundColor:UIColorFromRGB(0x262626)];
                [self.view addSubview:remoteView];
                [_remoteViewDic setObject:remoteView forKey:userId];
                // 将新进来的成员设置成大画面
                _mainViewUserId = userId;
                //布局
                [self relayout];
                [self.settingsManager updateCloudMixtureParams];
            }
            //开始远程画面
            [_trtc startRemoteView:userId view:remoteView];
            [_trtc setRemoteViewFillMode:userId mode:TRTCVideoFillMode_Fill];
            //停止呼叫计时
            [self invalidateCallTimer];
            //开始视频计时
            self.timerTaskId = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
            self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(videoTimeCount) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
        } else {
            [_trtc stopRemoteView:userId];
        }
        //[remoteView showVideoCloseTip:!available];
    }
}

- (void)onUserSubStreamAvailable:(NSString *)userId available:(BOOL)available {
    NSString* viewId = [NSString stringWithFormat:@"%@-sub", userId];
    if (available) {
        TRTCVideoView *remoteView = [TRTCVideoView newVideoViewWithType:VideoViewType_Remote userId:userId];
        remoteView.streamType = TRTCVideoStreamTypeSub;
        if (!self.settingsManager.audioConfig.isVolumeEvaluationEnabled) {
            [remoteView showAudioVolume:NO];
        }
        remoteView.delegate = self;
        [remoteView setBackgroundColor:UIColorFromRGB(0x262626)];
        [self.view addSubview:remoteView];
        [_remoteViewDic setObject:remoteView forKey:viewId];
        
        [_trtc startRemoteSubStreamView:userId view:remoteView];
        [_trtc setRemoteSubStreamViewFillMode:userId mode:TRTCVideoFillMode_Fill];
    }
    else {
        UIView *playerView = [_remoteViewDic objectForKey:viewId];
        [playerView removeFromSuperview];
        [_remoteViewDic removeObjectForKey:viewId];
        [_trtc stopRemoteSubStreamView:userId];
        
        if ([viewId isEqual:_mainViewUserId]) {
            _mainViewUserId = self.param.userId;
        }
    }
    [self relayout];
}

- (void)onUserVoiceVolume:(NSArray<TRTCVolumeInfo *> *)userVolumes totalVolume:(NSInteger)totalVolume {
    
}

- (void)onAudioEffectFinished:(int)effectId code:(int)code {
    //[self.effectManager stopEffect:effectId];
}

- (void)onNetworkQuality:(TRTCQualityInfo *)localQuality remoteQuality:(NSArray<TRTCQualityInfo *> *)remoteQuality {
//    [_localView setNetworkIndicatorImage:[self imageForNetworkQuality:localQuality.quality]];
//    for (TRTCQualityInfo* qualityInfo in remoteQuality) {
//        TRTCVideoView* remoteVideoView = [_remoteViewDic objectForKey:qualityInfo.userId];
//        [remoteVideoView setNetworkIndicatorImage:[self imageForNetworkQuality:qualityInfo.quality]];
//    }
}

// 信号图片
- (UIImage*)imageForNetworkQuality:(TRTCQuality)quality {
    UIImage* image = nil;
    switch (quality) {
        case TRTCQuality_Down:
        case TRTCQuality_Vbad:
            image = [UIImage imageNamed:@"signal5"];
            break;
        case TRTCQuality_Bad:
            image = [UIImage imageNamed:@"signal4"];
            break;
        case TRTCQuality_Poor:
            image = [UIImage imageNamed:@"signal3"];
            break;
        case TRTCQuality_Good:
            image = [UIImage imageNamed:@"signal2"];
            break;
        case TRTCQuality_Excellent:
            image = [UIImage imageNamed:@"signal1"];
            break;
        default:
            break;
    }
    return image;
}

#pragma mark - TRTCCloudManagerDelegate
- (void)roomSettingsManager:(TRTCCloudManager *)manager didSetVolumeEvaluation:(BOOL)isEnabled {
    for (TRTCVideoView* videoView in _remoteViewDic.allValues) {
        [videoView showAudioVolume:isEnabled];
    }
}

@end
