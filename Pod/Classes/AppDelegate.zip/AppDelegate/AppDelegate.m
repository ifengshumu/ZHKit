//
//  AppDelegate.m
//  PPYLiFeng
//
//  Created by Murphy on 2018/12/30.
//  Copyright © 2018年 Murphy. All rights reserved.
//

#import "AppDelegate.h"
#import <Speech/Speech.h>

#import "AppLauncher.h"
#import "ZHShare.h"
#import "ZHNotificationManager.h"
#import "AppStartImageScrollView.h"


@interface AppDelegate ()

@end


@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //主窗口
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = UIColor.whiteColor;
    [self.window makeKeyAndVisible];
    [AppLauncher appLaunchingWithOptions:launchOptions window:self.window];
    //判断登陆
    if ([AppService isLogin]) {
        MFTabBarController *vc = [[MFTabBarController alloc] init];
        self.window.rootViewController = vc;
        
        AppStartImageScrollView *ad = [[AppStartImageScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        ad.appStartImage = [UIImage imageNamed:@"appStartImage"];
        [self.window addSubview:ad];
        @weakify(ad);
        ad.endBlock = ^{
            @strongify(ad);
            [ad removeFromSuperview];
            [vc showStartGuide];
            [vc.view transitionWithType:@"oglFlip" WithSubtype:kCATransitionFromRight];
        };
    } else {
        [AppService goToLoginPage];
    }
    return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    //微信分享-wxc34305f022e13792://platformId=wechat
    if ([url.host isEqualToString:@"platformId=wechat"]) {
        return [ZHShareManager handleOpenURL:url options:options];
    }
    //微博分享-wb2579773232://response?id=xxx&sdkversion=xxx
    if ([url.scheme isEqualToString:@"wb2579773232"]) {
        return [ZHShareManager handleOpenURL:url options:options];
    }
    return YES;
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    [[ZHNotificationManager sharedManager] registerDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"注册远程推送失败：%@", error.description);
}

//iOS10之前及静默推送调用
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    NSDictionary *aps = userInfo[@"aps"];
    //静默推送，可以悄悄地做一些事
    if ([aps[@"content-available"] integerValue] == 1) {
        [[ZHNotificationManager sharedManager] handleSlientRemoteNotification:userInfo];
    }
    //处理推送
    [[ZHNotificationManager sharedManager] handleNotificationUserinfo:userInfo isForegroundMode:application.applicationState == UIApplicationStateActive];
    //回调
    completionHandler(UIBackgroundFetchResultNewData);
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

/*********    禁用横屏    *********/
- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    if (_allowLandscape) {
        return UIInterfaceOrientationMaskLandscapeRight;
    } else {
        return UIInterfaceOrientationMaskPortrait;
    }
}

@end
