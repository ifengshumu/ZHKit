//
//  AppService.h
//
//  Created by 李志华 on 2019/6/26.
//

#import <Foundation/Foundation.h>
#import "MFTabBarController.h"
#import "MFNavigationController.h"
#import "UserInfoModel.h"
#import "ProjectBoardResponse.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, TabPage) {
    TabPageNews     = 0,
    TabPageWork     = 1,
    TabPageBoard    = 2,
    TabPageMine     = 3
};

@interface AppService : NSObject

@property (nonatomic, strong) MFTabBarController *tabBarController;
@property (class, nonatomic, readonly) MFNavigationController *navigationController;

// 用于记录点击拍照页面之前的tab index
@property (nonatomic, assign) NSInteger pageIndex;

+ (instancetype)defaultService;

///用户id
+ (NSString *)uid;

/// 临时保存项目看板模块选择的项目id和项目名称
+ (void)saveTemporaryProjectId:(NSString *)projectId
                   projectName:(NSString *)projectName;

/// 获取进入项目看板保存的临时项目id
+ (NSString *)temporaryProjectId;

/// 获取进入项目看板保存的临时项目名称
+ (NSString *)temporaryProjectName;


/**
 拨打电话
*/
+ (void)callPhone:(NSString *)number;

/**
 超级管理员
*/
+ (BOOL)isAdmin;

/**
 姓名
*/
+ (NSString *)userName;

/**
 手机号
*/
+ (NSString *)mobile;

/**
 手机号
*/
+ (NSString *)secretMobile;

/**
 是否登录
*/
+ (BOOL)isLogin;

/**
 跳到登录页
 */
+ (void)goToLoginPage;

/**
 跳到主页面
 */
+ (void)goToMainPage;

/**
 回到tab页面
 */
+ (void)goToTabPage:(TabPage)tabPage;

/**
 回到tab页面，拍照页面
 */
+ (void)goToTabForCarema;

/// 判断是否是第一次打开app
+ (void)setIsFirstOpen:(BOOL)isFirstOpen;

/// 判断是否是第一次打开app
+ (BOOL)isFirstOpen;

/// 设置是否提醒免密登录
+ (void)setNeedLoginWithoutCode:(BOOL)code;

/// 是否提醒免密登录
+ (BOOL)needLoginWithoutCode;

/// 保存是否已开启免密登录
+ (void)setHasOpenLoginWithoutCode:(BOOL)code;

/// 是否已开启免密登录
+ (BOOL)hasOpenLoginWithoutCode;

//// 保存手机号&密码
+ (void)saveMobile:(NSString *)mobile password:(NSString *)password;

///登陆手机号和密码，0-手机号，1-密码
+ (NSArray *)getMobileAndPassword;

/**
 保存Token
*/
+ (void)saveToken:(NSString *)token;

/**
 获取Token
*/
+ (nullable NSString *)getToken;

/**
 移除Token
*/
+ (void)removeToken;

/**
 保存用户信息
*/
+ (void)saveUserInfo:(UserInfoModel *)userInfo;

/**
 获取用户信息
*/
+ (nullable UserInfoModel *)getUserInfo;

/**
 移除用户信息
*/
+ (void)removeUserInfo;





/**
 保存RegistrationID
*/
+ (void)saveRegistrationID:(NSString *)registrationID;

/**
 获取RegistrationID
*/
+ (nullable NSString *)getRegistrationID;


/// 通知打开页面
+ (void)handleOpenPage:(NSString *)page params:(id)info;

@end

NS_ASSUME_NONNULL_END
