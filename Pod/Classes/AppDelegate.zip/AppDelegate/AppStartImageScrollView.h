//
//  AppStartImageScrollView.h
//  PPYLingLingQi
//
//  Created by Murphy on 2018/8/3.
//  Copyright © 2018年 Murphy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppStartImageScrollView : UIScrollView

@property (strong, nonatomic) UIImage *appStartImage;
//@property (strong, nonatomic) NSString *appStartImage;
@property (copy, nonatomic) void (^endBlock)(void);

@end
