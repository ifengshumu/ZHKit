//
//  AccountService.m
//  CheryNewRetail
//
//  Created by 李志华 on 2019/6/26.
//

#import "AppService.h"

#import "LoginViewController.h"
#import "NewsListController.h"


@interface AppService ()
@property (nonatomic, assign) BOOL hasShowLogout;
@end

static AppService *service = nil;
@implementation AppService

+ (instancetype)defaultService {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        service = [[self alloc] init];
    });
    return service;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(foundAccessTokenInvalidError:) name:@"AccessTokenInvalid" object:nil];
    }
    return self;
}

//收到401 token失效的通知后，先调刷新token接口
- (void)foundAccessTokenInvalidError:(NSNotification *)notify {
    
}

- (void)refreshAccessTokenFailed {
    if ([AppService isLogin]) {
        //先移除token
        [AppService removeToken];
        [AppService removeUserInfo];
        [[NSNotificationCenter defaultCenter] postNotificationName:PPLogoutSuccessNotification object:nil];
        
    }
}

+ (MFNavigationController *)navigationController {
    return [AppService defaultService].tabBarController.selectedViewController;
}

+ (void)callPhone:(NSString *)number {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",number]];
    if (@available(iOS 10.0, *)) {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    } else {
        [ZHAlertView showAlertWithTitle:number confirmTitle:@"呼叫" cancelTitle:@"取消" confirmHandler:^{
            [[UIApplication sharedApplication] openURL:url];
        } cancelHandler:nil];
    }
}

+ (BOOL)isAdmin {
    UserInfoModel *m = [self getUserInfo];
    if (m) {
        return [m.role_code isEqualToString:@"admin"];
    } else {
        return NO;
    }
}

/// 用户id
+ (NSString *)uid {
    UserInfoModel *m = [self getUserInfo];
    if (m) {
        return m.show_id;
    } else {
        return @"";
    }
}

/// 临时保存项目看板模块选择的项目id和项目名称
+ (void)saveTemporaryProjectId:(NSString *)projectId
                   projectName:(NSString *)projectName
{
    [self saveObject:projectId key:@"temporary_projectId"];
    [self saveObject:projectName key:@"temporary_projectName"];
}

/// 获取进入项目看板保存的临时项目id
+ (NSString *)temporaryProjectId
{
    return [self getObject:@"temporary_projectId"];
}

/// 获取进入项目看板保存的临时项目名称
+ (NSString *)temporaryProjectName
{
    return [self getObject:@"temporary_projectName"];
}

+ (NSString *)userName {
    UserInfoModel *m = [self getUserInfo];
    if (m) {
        return m.username;
    } else {
        return @"";
    }
}

+ (NSString *)mobile {
    UserInfoModel *m = [self getUserInfo];
    if (m) {
        return m.mobile;
    } else {
        return @"";
    }
}

+ (NSString *)secretMobile {
    UserInfoModel *m = [self getUserInfo];
    if (m) {
        return [NSString getSecrectStringWithPhoneNumber:m.mobile];
    } else {
        return @"";
    }
}

+ (BOOL)isLogin {
    NSString *token = [self getToken];
    UserInfoModel *userModel = [self getUserInfo];
    if (token && userModel) {
        return YES;
    }
    return NO;
}

+ (void)goToLoginPage {
    UIWindow *window = [UIApplication sharedApplication].delegate.window;
    LoginViewController *vc = [[LoginViewController alloc] init];
    MFNavigationController *nav = [[MFNavigationController alloc] initWithRootViewController:vc];
    window.rootViewController = nav;
}

+ (void)goToMainPage {
    UIWindow *window = [UIApplication sharedApplication].delegate.window;
    MFTabBarController *vc = [[MFTabBarController alloc] init];
    window.rootViewController = vc;
    [window transitionWithType:@"oglFlip" WithSubtype:kCATransitionFromRight];
}

+ (void)goToTabPage:(TabPage)tabPage {
    [AppService.navigationController popToRootViewControllerAnimated:NO];
    if ([self isAdmin] && tabPage > TabPageWork) {
        tabPage++;
    }
    [AppService defaultService].tabBarController.selectedIndex = tabPage;
}

+ (void)goToTabForCarema {
    NSInteger tabPage = [AppService defaultService].pageIndex;
    [AppService defaultService].tabBarController.selectedIndex = tabPage;
}

// 判断是否是第一次打开app
+ (void)setIsFirstOpen:(BOOL)isFirstOpen {
    [self saveObject:@(isFirstOpen) key:@"isFirstOpen"];
}

// 判断是否是第一次打开app
+ (BOOL)isFirstOpen {
    if (![self getObject:@"isFirstOpen"]) {
        return YES;
    }
    return [[self getObject:@"isFirstOpen"] boolValue];
}

// 设置是否提醒免密登录
+ (void)setNeedLoginWithoutCode:(BOOL)code {
    [self saveObject:@(code) key:@"NeedLoginWithoutCode"];
}

// 是否提醒免密登录
+ (BOOL)needLoginWithoutCode {
    NSNumber *code = [self getObject:@"NeedLoginWithoutCode"];
    if (!code) {
        return YES;
    }
    return [code boolValue];
}

+ (void)setHasOpenLoginWithoutCode:(BOOL)code {
    [self saveObject:@(code) key:@"HasOpenLoginWithoutCode"];
}

+ (BOOL)hasOpenLoginWithoutCode {
    return [[self getObject:@"HasOpenLoginWithoutCode"] boolValue];
}

+ (void)saveMobile:(NSString *)mobile password:(NSString *)password {
    NSArray *mpd = @[mobile,password];
    [self saveObject:mpd key:@"PPYLF_MobileAndPassword"];
}

+ (NSArray *)getMobileAndPassword {
    return [self getObject:@"PPYLF_MobileAndPassword"];
}

+ (void)saveToken:(NSString *)token {
    [self saveObject:token key:@"PPYLF_Token"];
}

+ (NSString *)getToken {
    return [self getObject:@"PPYLF_Token"];
}

+ (void)removeToken {
    [self removeObject:@"PPYLF_Token"];
}

+ (void)saveUserInfo:(UserInfoModel *)userInfo {
    NSString *user = userInfo.toJSONString;
    [self saveObject:user key:@"PPYLF_UserInfoModel"];
}

+ (UserInfoModel *)getUserInfo {
    NSString *user = [self getObject:@"PPYLF_UserInfoModel"];
    return [UserInfoModel modelWithJSONObject:user];
}

+ (void)removeUserInfo {
    [self removeObject:@"PPYLF_UserInfoModel"];
}



+ (void)saveRegistrationID:(NSString *)registrationID {
    [self saveObject:registrationID key:@"JPushRegistrationID"];
}

+ (NSString *)getRegistrationID {
    return [self getObject:@"JPushRegistrationID"];
}

/// 保存
+ (void)saveObject:(id)obj key:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setValue:obj forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
/// 获取
+ (id)getObject:(NSString *)key {
    id obj = [[NSUserDefaults standardUserDefaults] valueForKey:key];
    return obj;
}
/// 移除
+ (void)removeObject:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


+ (void)handleOpenPage:(NSString *)page params:(id)info {
    UIViewController *vc = AppService.navigationController.visibleViewController;
    if (![vc isKindOfClass:NewsListController.class]) {
        [AppService goToTabPage:TabPageNews];
    }
}

@end
