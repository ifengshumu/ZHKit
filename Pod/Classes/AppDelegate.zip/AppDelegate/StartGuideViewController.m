//
//  StartGuideViewController.m
//  PPYLiFeng
//
//  Created by 陈子介 on 2020/5/8.
//  Copyright © 2020 Murphy. All rights reserved.
//

#import "StartGuideViewController.h"

@interface StartGuideItem : NSObject
@property(nonatomic, assign) CGRect frame;
@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSString *des;
@property(nonatomic, strong) NSString *image;
@property(nonatomic, strong) NSString *btnTitle;
@property(nonatomic, assign) CGFloat cornerRadius;
@end

@implementation StartGuideItem

@end

@interface StartGuideViewController ()

@property(nonatomic, strong) CAShapeLayer *maskLayer;
@property(nonatomic, assign) NSInteger currentIndex;

// 中间主图
@property(nonatomic, strong) UIImageView *notiImageV;
// 下一步
@property(nonatomic, strong) UIButton *nextBtn;
@property(nonatomic, strong) UILabel *notiTitleLabel;
@property(nonatomic, strong) UILabel *notiDesLabel;

//手电筒图片
@property(nonatomic, strong) UIImageView *flashlightImageV;

@end

@implementation StartGuideViewController

///MARK: - Public
+ (void)showsInViewController:(UIViewController *)viewController {
    StartGuideViewController *guideVC = StartGuideViewController.new;
    [guideVC showsInViewController:viewController];
}

- (void)showsInViewController:(UIViewController *)viewController {
    self.modalPresentationStyle = UIModalPresentationCustom;
    [viewController.presentedViewController dismissViewControllerAnimated:NO completion:nil];
    [viewController presentViewController:self animated:NO completion:nil];
}

+ (BOOL)needShowGuideView {
    return ![mUserDefaults boolForKey:@"guide_view_had_show"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //添加子视图
    [self addSubviews];
    
    self.view.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    self.currentIndex = 0;
    
    if ([AppService isAdmin]) {
        [self nextAction];
    } else {
        [self showInvestGuide];
    }
}

- (void)addSubviews {
    self.flashlightImageV = [[UIImageView alloc] initWithImage:mImage(@"flashlight_img")];
    [self.view addSubview:self.flashlightImageV];
    
    self.nextBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.nextBtn.titleLabel.font = mFont(16);
    self.nextBtn.layer.cornerRadius = 23;
    self.nextBtn.layer.borderWidth = 1;
    self.nextBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.nextBtn addTarget:self action:@selector(nextAction) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:self.nextBtn];
    [self.nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(@-240);
        make.centerX.equalTo(self.view);
        make.width.equalTo(@130);
        make.height.equalTo(@46);
    }];
    
    self.notiDesLabel = [UILabel new];
    self.notiDesLabel.font = mFont(14);
    self.notiDesLabel.numberOfLines = 0;
    self.notiDesLabel.textAlignment = NSTextAlignmentCenter;
    self.notiDesLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:self.notiDesLabel];
    [self.notiDesLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.nextBtn.mas_top).offset(-25);
        make.centerX.equalTo(self.view);
        make.left.equalTo(@10);
        make.right.equalTo(@-10);
    }];
    
    self.notiTitleLabel = [UILabel new];
    self.notiTitleLabel.frame = CGRectMake(0, CGRectGetMaxY(self.notiImageV.frame)+20, mScreenWidth, 30);
    self.notiTitleLabel.font = mFontM(20);
    self.notiTitleLabel.textAlignment = NSTextAlignmentCenter;
    self.notiTitleLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:self.notiTitleLabel];
    [self.notiTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.notiDesLabel.mas_top).offset(-15);
        make.centerX.equalTo(self.view);
        make.left.equalTo(@10);
        make.right.equalTo(@-10);
    }];
    
    self.notiImageV = [[UIImageView alloc] init];
    [self.view addSubview:self.notiImageV];
    [self.notiImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.notiTitleLabel.mas_top).offset(-20);
        make.centerX.equalTo(self.view);
    }];
}

- (void)nextAction {
    if ([AppService isAdmin]) {
        if (self.currentIndex == 3) {
            [mUserDefaults setBool:YES forKey:@"guide_view_had_show"];
            [self dismissViewControllerAnimated:NO completion:nil];
            return;
        }
        [self showAdminGuideAtIndex:self.currentIndex++];
    } else {
        [mUserDefaults setBool:YES forKey:@"guide_view_had_show"];
        [self dismissViewControllerAnimated:NO completion:nil];
    }
}

#pragma mark - 超级管理
- (void)showAdminGuideAtIndex:(NSInteger)index {
    if (index < 0) {
        self.currentIndex = 0;
        return;
    }
    
    CGFloat flashlightPaddingX = 26;
    CGFloat flashlightPaddingY = 88.5;
    CGFloat flashlightWidth = 82;
    CGFloat flashlightHeight = 113;
    
    CGPathRef fromPath = self.maskLayer.path;
    
    StartGuideItem *item = [self guideItemsForAdmin][index];
    
    UIBezierPath *visualPath = [UIBezierPath bezierPathWithRoundedRect:item.frame cornerRadius:item.cornerRadius];
    UIBezierPath *toPath = [UIBezierPath bezierPathWithRect:self.view.bounds];
    [toPath appendPath:visualPath];
    
    /// 遮罩的路径
    self.maskLayer.path = toPath.CGPath;
    self.view.layer.mask = self.maskLayer;
    
    
    self.flashlightImageV.frame = CGRectMake(item.frame.origin.x-flashlightPaddingX, item.frame.origin.y-flashlightPaddingY, flashlightWidth, flashlightHeight);
  
    /// 开始移动动画
    if (fromPath && toPath) {
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"path"];
        animation.duration = 0.2;
        animation.fromValue = (__bridge id _Nullable)(fromPath);
        animation.toValue = (__bridge id _Nullable)(toPath.CGPath);
        [self.maskLayer addAnimation:animation forKey:nil];
    }
    
    if (index > 0) {
        StartGuideItem *preItem = [self guideItemsForAdmin][index-1];
        CGPoint anchorPoint = self.flashlightImageV.layer.anchorPoint;

        CABasicAnimation *animation=[CABasicAnimation animationWithKeyPath:@"position"];
        animation.duration=0.2;
        animation.fromValue=[NSValue valueWithCGPoint:CGPointMake(preItem.frame.origin.x-flashlightPaddingX + anchorPoint.x*flashlightWidth, preItem.frame.origin.y-flashlightPaddingY+anchorPoint.y*flashlightHeight)];
        animation.toValue=[NSValue valueWithCGPoint:CGPointMake(item.frame.origin.x-flashlightPaddingX + anchorPoint.x*flashlightWidth, item.frame.origin.y-flashlightPaddingY+anchorPoint.y*flashlightHeight)];
        [self.flashlightImageV.layer addAnimation:animation forKey:@"frameChange"];
    }
    
    self.notiImageV.image = mImage(item.image);
    self.notiTitleLabel.text = item.title;
    self.notiDesLabel.text = item.des;
    [self.nextBtn setTitle:item.btnTitle forState:(UIControlStateNormal)];
}

- (NSArray *)guideItemsForAdmin {
    CGFloat itemWidth = mScreenWidth/5.0;
    CGFloat y = mScreenHeight-mBottomSafeH-mTabBarH;
    CGFloat cornerRadius = mNavBarH/2.0;
    
    StartGuideItem *item0 = StartGuideItem.new;
    item0.title = @"明确进度安排";
    item0.des = @"及时有效解决建设问题";
    item0.btnTitle = @"下一步";
    item0.image = @"start_guide_01";
    item0.cornerRadius = cornerRadius;
    item0.frame = CGRectMake(itemWidth*1.0, y, itemWidth, mTabBarH);
    
    StartGuideItem *item1 = StartGuideItem.new;
    item1.title = @"快速新建工单";
    item1.des = @"让工单创建更加快捷";
    item1.btnTitle = @"下一步";
    item1.image = @"start_guide_02";
    item1.cornerRadius = cornerRadius;
    item1.frame = CGRectMake(itemWidth*2.0, y, itemWidth, mTabBarH);
    
    StartGuideItem *item2 = StartGuideItem.new;
    item2.title = @"项目精细化管理";
    item2.des = @"将管理责任具体化、明确化";
    item2.btnTitle = @"知道了";
    item2.image = @"start_guide_03";
    item2.cornerRadius = cornerRadius;
    item2.frame = CGRectMake(itemWidth*3.0, y, itemWidth, mTabBarH);
    
    return @[item0, item1, item2];
}

#pragma mark - 投资人
- (void)showInvestGuide {
    StartGuideItem *item = [self guideItemsForInvest];
    
    UIBezierPath *visualPath = [UIBezierPath bezierPathWithRoundedRect:item.frame cornerRadius:item.cornerRadius];
    UIBezierPath *toPath = [UIBezierPath bezierPathWithRect:self.view.bounds];
    [toPath appendPath:visualPath];
    /// 遮罩的路径
    self.maskLayer.path = toPath.CGPath;
    self.view.layer.mask = self.maskLayer;
    
    self.flashlightImageV.image = UIImageNamed(@"flashlight_top");
    self.flashlightImageV.frame = CGRectMake(CGRectGetMinX(item.frame)-8, CGRectGetMidY(item.frame)-10, 65, 120);
  
    self.notiTitleLabel.text = item.title;
    self.notiDesLabel.text = item.des;
    [self.nextBtn setTitle:item.btnTitle forState:(UIControlStateNormal)];
}

- (StartGuideItem *)guideItemsForInvest {
    StartGuideItem *item = StartGuideItem.new;
    item.title = @"登陆后台管理系统：";
    item.des = @"二维码登陆——工程资料管理——平面图纸下载查看";
    item.btnTitle = @"知道了";
    item.cornerRadius = mTabBarH /2.0;
    item.frame = CGRectMake(mScreenWidth-115, mStatusH, 60, mNavBarH);
    return item;
}



- (CAShapeLayer *)maskLayer {
    if (!_maskLayer) {
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        _maskLayer = maskLayer;
        maskLayer.fillRule = kCAFillRuleEvenOdd;
    }
    return _maskLayer;
}

@end
