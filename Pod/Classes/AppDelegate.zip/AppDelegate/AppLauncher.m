//
//  AppLauncher.m
//
//  Created by 李志华 on 2019/7/6.
//

#import "AppLauncher.h"
#import "ZHNotificationManager.h"
#import "ZHShare.h"
#import "MapService.h"
#import <AvoidCrash/AvoidCrash.h>
#import <Bugly/Bugly.h>


static NSString *const AppKey_UM        = @"5d440ba24ca357ebc3000900";
//微信
static NSString *const AppKey_WX        = @"wxc34305f022e13792";
static NSString *const AppSecret_WX     = @"1537170020a0727d376b336c29c122b4";
//新浪
static NSString *const AppKey_Sina      = @"";
static NSString *const AppSecret_Sina   = @"";
static NSString *const RedirectURL      = @"https://api.weibo.com/oauth2/default.html";

@implementation AppLauncher

+ (void)appLaunchingWithOptions:(NSDictionary *)launchOptions window:(UIWindow *)window {
    [self configUI];;
    [self configNetwork];
    [self configurePushSDK:launchOptions];
    [self configureShare];
    [self configureMap];
    [self configureKeyboard];
//    [self configureCrash];
}

+ (void)configUI {
    // 修改全体UIAlertController字体大小
    UILabel *appearanceLabel = [UILabel appearanceWhenContainedInInstancesOfClasses:@[BaseAlertViewController.class]];
    [appearanceLabel changeFont:mFont(15)];
}

+ (void)configNetwork {
    
}

+ (void)configurePushSDK:(NSDictionary *)launchOptions {
    ZHNotificationManager *manager = [ZHNotificationManager sharedManager];
    [manager startPushSDKWithOptions:launchOptions];
    [manager registrationIDCompletionHandler:^(int resCode, NSString *registrationID) {
        if (registrationID) {
            [CommonAPI uploadJPushRegistractionId:registrationID result:^(BOOL success, id  _Nonnull responseObject) {
                if (success) {
                    NSLog(@"JPUSH registrationID upload success");
                } else {
                    NSLog(@"JPUSH registrationID upload fail");
                }
            }];
        }
    }];
}

+ (void)configureShare {
    [ZHShareManager setSocialShareAppkey:AppKey_UM];
    [ZHShareManager setPlaform:SharePlatformTypeWxSession appKey:AppKey_WX appSecret:AppSecret_WX redirectURL:nil];
    [ZHShareManager setPlaform:SharePlatformTypeWxTimeLine appKey:AppKey_WX appSecret:AppSecret_WX redirectURL:nil];
}

+ (void)configureMap {
    [MapService startLocationWithCompletionResult:^(CLLocation * _Nullable location, AMapLocationReGeocode * _Nullable regeocode) {
        
    }];
}

+ (void)configureKeyboard {
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager];
    keyboardManager.shouldResignOnTouchOutside = YES; // 控制点击背景是否收起键盘
    keyboardManager.shouldShowToolbarPlaceholder = NO; // 是否显示占位文字
    keyboardManager.toolbarTintColor = mRGBnavcolor;
    keyboardManager.toolbarNextBarButtonItemImage = [UIImage keyboardNextImage];
}


+ (void)configureCrash {
    //AvoidCrash
    [AvoidCrash becomeEffective];
    
    //bugly
    BuglyConfig *config = [[BuglyConfig alloc] init];
    config.blockMonitorEnable = YES;
    config.blockMonitorTimeout = 2;
    [Bugly startWithAppId:@"xxxx" config:config];
    [[NSNotificationCenter defaultCenter] addObserverForName:AvoidCrashNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        NSDictionary *info = note.userInfo;
        NSString *errorName = info[@"errorName"];
        NSString *errorReason = [NSString stringWithFormat:@"【ErrorReason】：%@\n\r【ErrorPlace】：%@", info[@"errorReason"], info[@"errorPlace"]];
        NSArray *callStack = info[@"callStackSymbols"];
        NSException *exception = info[@"exception"];
        [Bugly reportExceptionWithCategory:3 name:errorName reason:errorReason callStack:callStack extraInfo:exception.userInfo terminateApp:NO];
    }];
}

@end
