//
//  AppDelegate.h
//  PPYLiFeng
//
//  Created by Murphy on 2018/12/30.
//  Copyright © 2018年 Murphy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

/// 允许横屏
@property (nonatomic, assign) BOOL allowLandscape;

@end

