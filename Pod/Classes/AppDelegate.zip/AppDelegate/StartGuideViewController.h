//
//  StartGuideViewController.h
//  PPYLiFeng
//
//  Created by 陈子介 on 2020/5/8.
//  Copyright © 2020 Murphy. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface StartGuideViewController : UIViewController

+ (void)showsInViewController:(UIViewController *)viewController;
+ (BOOL)needShowGuideView;
@end

NS_ASSUME_NONNULL_END
