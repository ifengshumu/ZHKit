//
//  AppStartImageScrollView.m
//  PPYLingLingQi
//
//  Created by Murphy on 2018/8/3.
//  Copyright © 2018年 Murphy. All rights reserved.
//

#import "AppStartImageScrollView.h"
#import "UIButton+TouchAreaInsets.h"


@interface AppStartImageScrollView () <UIScrollViewDelegate>

@property (strong, nonatomic) BaseImageView *showImage;
@property (strong, nonatomic) UIButton *timeBtn;

@end


@implementation AppStartImageScrollView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.contentSize = CGSizeMake(mScreenWidth, mScreenHeight);
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.pagingEnabled = YES;
        self.bounces = NO;
        self.delegate = self;
        self.backgroundColor = [UIColor whiteColor];
        self.userInteractionEnabled = YES;
        
        
        _showImage = [[BaseImageView alloc]init];
        _showImage.frame = CGRectMake(0, 0, mScreenWidth, mScreenHeight-H(80));
        _showImage.backgroundColor = [UIColor whiteColor];
        _showImage.userInteractionEnabled = YES;
        [self addSubview:_showImage];
        
        
        UIView *downView = [UIView new];
        downView.frame = CGRectMake(0, mScreenHeight-H(120), mScreenWidth, H(120));
        downView.backgroundColor = [UIColor whiteColor];
        [self addSubview:downView];

        UIImageView *iconImage = [UIImageView new];
        iconImage.center = CGPointMake(mScreenWidth/2, H(45));
        iconImage.bounds = CGRectMake(0, 0, H(50), H(50));
        iconImage.image = mImage(@"lf_launch_logo");
        iconImage.layer.cornerRadius = H(12);
        iconImage.clipsToBounds = YES;
        [downView addSubview:iconImage];

        UILabel *title = [UILabel new];
        title.frame = CGRectMake(0, CGRectGetMaxY(iconImage.frame), mScreenWidth, H(30));
        title.font = mFont(12);
        title.textColor = mRGBgfontcolor;
        title.text = @"—— 小助版权所有©2019 ——";
        title.textAlignment = NSTextAlignmentCenter;
        [downView addSubview:title];
        
        
        UIButton *timeBtn = [UIButton new];
        timeBtn.frame = CGRectMake(mScreenWidth-W(75), mScreenHeight-H(165), W(60), H(30));
        timeBtn.backgroundColor = mRGBAcolor(200, 200, 200, 0.3);
        timeBtn.layer.cornerRadius = H(15);
        timeBtn.clipsToBounds = YES;
        timeBtn.titleLabel.font = mFont(15);
        [timeBtn setTitleColor:UIColor.deepBlueColor forState:0];
        [timeBtn setTitle:@"3秒" forState:0];
        _timeBtn = timeBtn;
        [self addSubview:timeBtn];
        
        
        __block NSInteger timeOut = 3;
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
        dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
        dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), 1.0*NSEC_PER_SEC, 0);
        dispatch_source_set_event_handler(_timer, ^{
            if(timeOut <= 0) {
                // 倒计时结束，关闭
                dispatch_source_cancel(_timer);
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.endBlock();
                });
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{

                    NSString *downStr = [NSString stringWithFormat:@"%ld秒",timeOut];
                    [timeBtn setTitle:downStr forState:0];
                    timeOut--;
                });
            }
        });
        dispatch_resume(_timer);
        
        [timeBtn addTouchUpInsideEventUsingBlock:^(UIButton * _Nonnull sender) {
            self.endBlock();
            dispatch_source_cancel(_timer);
        }];
    }
    return self;
}

// 重复执行的定时器
- (void)gcdTimer1
{
    // 获取全局队列
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    // 创建定时器
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    // 开始时间
    dispatch_time_t start = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC));
    // 重复间隔
    uint64_t interval = (uint64_t)(1.0 * NSEC_PER_SEC);
    // 设置定时器
    dispatch_source_set_timer(_timer, start, interval, 0);
    // 设置需要执行的事件
    dispatch_source_set_event_handler(_timer, ^{
        
        // 在这里执行事件
        static NSInteger num = 3;
        NSLog(@"%ld", (long)num);
        num--;
        if (num <= 0)
        {
            [UIView animateWithDuration:0.5 animations:^{
                
                self.timeBtn.alpha = 0;
                self.alpha = 0;
                self.timeBtn.layer.transform = CATransform3DScale(CATransform3DIdentity, 1.5, 1.5, 1.5);
                self.layer.transform = CATransform3DScale(CATransform3DIdentity, 1.5, 1.5, 1.5);
            }];
            NSLog(@"end");
            
            // 关闭定时器
            dispatch_source_cancel(_timer);
        }else
        {
            NSString *downStr = [NSString stringWithFormat:@"%ld秒",num];
            [self.timeBtn setTitle:downStr forState:0];
        }
    });
    // 开启定时器
    dispatch_resume(_timer);
    NSLog(@"start");
}

- (void)setAppStartImage:(UIImage *)appStartImage
{
    _appStartImage = appStartImage;
    _showImage.image = appStartImage;
}

@end
