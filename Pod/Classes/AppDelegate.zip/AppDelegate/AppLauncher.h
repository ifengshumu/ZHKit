//
//  AppLauncher.h
//
//  Created by 李志华 on 2019/7/6.
//

#import <Foundation/Foundation.h>

@interface AppLauncher : NSObject

/**
 APP启动时所做的操作
 */
+ (void)appLaunchingWithOptions:(NSDictionary *)launchOptions window:(UIWindow *)window;
@end

